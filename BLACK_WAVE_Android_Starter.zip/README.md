# BLACK WAVE — Android Launcher starter

This is the first runnable foundation for the BLACK WAVE Android home-screen launcher.

## What is included
- Android HOME/DEFAULT launcher activity
- Digital clock and date
- Dark monochrome home screen
- App drawer with installed launcher activities
- Search and app launching
- Lightweight abstract wave placeholder

## What is not included yet
- Final ocean-wave artwork
- Custom icon packs applied to every app
- Live wallpaper service
- 3D / gyroscope interaction
- Theme store, accounts, payments
- Lock-screen or system UI replacement

## Build
Open this folder in Android Studio or a compatible Android Gradle environment.
Use JDK 17 and Android SDK 35. Sync Gradle, then build the debug APK.

On first launch, Android may ask whether BLACK WAVE should be used as the default Home app.
Choose BLACK WAVE to test it as your launcher. You can switch back from Android Settings > Apps > Default apps > Home app.

## Important
The app requests launcher-visible apps through an intent query rather than QUERY_ALL_PACKAGES.
Google Play distribution still requires policy and device testing before release.
