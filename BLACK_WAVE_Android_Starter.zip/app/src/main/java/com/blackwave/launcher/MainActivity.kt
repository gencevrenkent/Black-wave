package com.blackwave.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF080A0F)
private val Muted = Color(0xFF9DA3AE)
private val Aqua = Color(0xFFB9E7E8)

data class LaunchableApp(
    val label: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 6, 8)
        window.navigationBarColor = android.graphics.Color.rgb(5, 6, 8)
        setContent {
            BlackWaveApp(
                apps = remember { loadApps() },
                onLaunch = { packageName ->
                    packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
                }
            )
        }
    }

    private fun loadApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val activityInfo = info.activityInfo ?: return@mapNotNull null
                if (activityInfo.packageName == packageName) return@mapNotNull null
                LaunchableApp(
                    label = info.loadLabel(packageManager).toString(),
                    packageName = activityInfo.packageName,
                    icon = info.loadIcon(packageManager)
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }
}

@Composable
private fun BlackWaveApp(
    apps: List<LaunchableApp>,
    onLaunch: (String) -> Unit
) {
    var showDrawer by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(Date()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }
    BackHandler(enabled = showDrawer) { showDrawer = false }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(Color(0xFF090B12), Color(0xFF151923), Color(0xFF050609))
                )
            )
    ) {
        // Temporary abstract wave treatment. Replace with licensed artwork in the next pass.
        WaveArtwork(Modifier.fillMaxSize())

        AnimatedVisibility(
            visible = !showDrawer,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            HomeScreen(
                now = now,
                onOpenDrawer = { showDrawer = true }
            )
        }

        AnimatedVisibility(
            visible = showDrawer,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            AppDrawer(
                apps = apps,
                onBack = { showDrawer = false },
                onLaunch = onLaunch
            )
        }
    }
}

@Composable
private fun HomeScreen(now: Date, onOpenDrawer: () -> Unit) {
    val time = remember(now) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    }
    val date = remember(now) {
        SimpleDateFormat("EEEE  •  dd MMMM", Locale.getDefault())
            .format(now).uppercase(Locale.getDefault())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 28.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Spacer(Modifier.weight(0.35f))
        Text(
            text = time,
            color = Color.White,
            fontSize = 76.sp,
            lineHeight = 80.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = (-4).sp
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = date,
            color = Aqua,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.2.sp
        )
        Spacer(Modifier.weight(1f))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "BLACK\nWAVE",
                color = Color.White.copy(alpha = 0.76f),
                fontSize = 11.sp,
                lineHeight = 15.sp,
                letterSpacing = 3.sp,
                fontWeight = FontWeight.Medium
            )
            Surface(
                onClick = onOpenDrawer,
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.10f),
                contentColor = Color.White
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Apps, contentDescription = "Uygulamalar")
                    Spacer(Modifier.width(8.dp))
                    Text("UYGULAMALAR", fontSize = 10.sp, letterSpacing = 1.4.sp)
                }
            }
        }
    }
}

@Composable
private fun AppDrawer(
    apps: List<LaunchableApp>,
    onBack: () -> Unit,
    onLaunch: (String) -> Unit
) {
    var search by remember { mutableStateOf("") }
    val filtered = remember(apps, search) {
        apps.filter { it.label.contains(search, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF2090B10))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 22.dp, bottom = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("UYGULAMALAR", color = Color.White, fontSize = 18.sp, letterSpacing = 2.sp)
                Text("${filtered.size} UYGULAMA", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
            TextButton(onClick = onBack) { Text("KAPAT", color = Aqua) }
        }

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Uygulama ara", color = Muted) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = Aqua) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Aqua,
                unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                cursorColor = Aqua
            ),
            shape = RoundedCornerShape(18.dp)
        )

        Spacer(Modifier.height(18.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            items(filtered, key = { it.packageName }) { app ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onLaunch(app.packageName) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val iconBitmap = remember(app.packageName) { drawableToBitmap(app.icon) }
                    androidx.compose.foundation.Image(
                        bitmap = iconBitmap.asImageBitmap(),
                        contentDescription = app.label,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = app.label,
                        color = Color.White.copy(alpha = 0.88f),
                        fontSize = 10.sp,
                        maxLines = 2,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun WaveArtwork(modifier: Modifier = Modifier) {
    // Lightweight abstract wave made from layered translucent curves.
    // The next design pass will replace this with custom Black Wave artwork.
    androidx.compose.foundation.Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        for (i in 0..18) {
            val y = h * (0.48f + i * 0.018f)
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(w * 0.36f, y)
                cubicTo(w * 0.55f, y - h * 0.12f, w * 0.60f, y + h * 0.13f, w * 1.08f, y - h * 0.04f)
                lineTo(w * 1.08f, y + h * 0.025f)
                cubicTo(w * 0.60f, y + h * 0.20f, w * 0.50f, y - h * 0.04f, w * 0.36f, y)
                close()
            }
            drawPath(
                path = path,
                color = Color(0xFFDCE5E9).copy(alpha = 0.012f + i * 0.0015f)
            )
        }
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color(0xFF090B10).copy(alpha = 0.15f), Color.Transparent)
            )
        )
    }
}


private fun drawableToBitmap(drawable: Drawable): Bitmap {
    val width = (drawable.intrinsicWidth.takeIf { it > 0 } ?: 96).coerceAtMost(192)
    val height = (drawable.intrinsicHeight.takeIf { it > 0 } ?: 96).coerceAtMost(192)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, width, height)
    drawable.draw(canvas)
    return bitmap
}
